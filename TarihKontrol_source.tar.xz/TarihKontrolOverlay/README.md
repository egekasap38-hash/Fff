# Tarih Kontrol – Shizuku sabit ekran paneli

## Kullanım
1. Shizuku'yu telefonda çalıştırıp Tarih Kontrol için izni onaylayın.
2. Tarih Kontrol'ü açın; **Sabit paneli aç** butonuna dokunun.
3. Sorulduğunda **Diğer uygulamaların üzerinde göster** iznini verin.
4. Uygulamaya dönüp yeniden **Sabit paneli aç** deyin.
5. Ekranın altındaki üç ikon diğer uygulamalarda da aynı konumda kalır:
   - Sol ok: tarihi 1 gün geri alma
   - Döngü: otomatik tarih/saati açma
   - Sağ ok: tarihi 1 gün ileri alma
6. Paneli kapatmak için Tarih Kontrol'ü açıp **Sabit paneli kapat** seçin.

**Not:** Sistem tarihini değiştirmek Shizuku ile bile bazı üretici sürümlerinde engellenebilir. Uygulama işlem sonucunu doğrulamaya çalışır.

## Derleme
`gradle :app:assembleDebug --no-daemon`

Android 8.0+ (API 26), hedef Android SDK 28, derleme SDK 36, JDK 17, Shizuku API 13.1.5.
