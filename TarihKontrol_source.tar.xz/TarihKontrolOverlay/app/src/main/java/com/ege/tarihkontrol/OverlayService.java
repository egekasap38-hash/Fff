package com.ege.tarihkontrol;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.concurrent.atomic.AtomicBoolean;
import rikka.shizuku.Shizuku;

public class OverlayService extends Service {
    static volatile boolean running = false;
    private static final String CHANNEL = "tarih_kontrol_overlay";
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private View floatingPanel;
    private final int[] buttonColors = {0xFFFFB76D, 0xFF79B1FF, 0xFF6DDCB3};

    @Override public void onCreate() {
        super.onCreate();
        createNotification();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        showPanel();
    }
    private void createNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Tarih Kontrol Paneli", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Ekranda sabit tarih kontrol butonları");
            manager.createNotificationChannel(channel);
        }
        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(this, 0, open, flags);
        Notification notification = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(com.ege.tarihkontrol.R.drawable.ic_launcher)
                .setContentTitle("Tarih Kontrol")
                .setContentText("Sabit butonlar ekranda açık")
                .setContentIntent(pending)
                .setOngoing(true)
                .build();
        startForeground(1207, notification);
    }
    private void showPanel() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        LinearLayout panel = new LinearLayout(this);
        panel.setGravity(Gravity.CENTER);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setPadding(dp(7), dp(7), dp(7), dp(7));
        GradientDrawable shell = new GradientDrawable();
        shell.setColor(0xEB131D30);
        shell.setCornerRadius(dp(24));
        shell.setStroke(dp(1), 0xAA536680);
        panel.setBackground(shell);
        panel.setElevation(dp(10));
        for (int action = -1; action <= 1; action++) addIcon(panel, action);
        int kind = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                kind,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        params.y = dp(74);
        try {
            windowManager.addView(panel, params);
            floatingPanel = panel;
            running = true;
        } catch (Exception e) {
            Toast.makeText(this, "Panel açılamadı: ekran üstü izni gerekli", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }
    private void addIcon(LinearLayout parent, int action) {
        int index = action + 1;
        IconView icon = new IconView(action, buttonColors[index]);
        icon.setContentDescription(action == -1 ? "Bir gün geri" : action == 0 ? "Otomatik saat" : "Bir gün ileri");
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(action == 0 ? 0xFF263955 : 0xFF202E45);
        bg.setCornerRadius(dp(18));
        icon.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(58), dp(58));
        lp.setMargins(dp(3), 0, dp(3), 0);
        parent.addView(icon, lp);
        icon.setOnClickListener(v -> runAction(action));
    }
    private void runAction(int action) {
        if (!busy.compareAndSet(false, true)) return;
        try {
            if (Shizuku.getBinder() == null || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                message("Shizuku bağlantısını kontrol et");
                busy.set(false);
                return;
            }
        } catch (Exception e) { message("Shizuku bağlantısı yok"); busy.set(false); return; }
        new Thread(() -> {
            String result;
            try {
                String command;
                long intended = 0;
                if (action == 0) {
                    command = "settings put global auto_time 1 && settings put global auto_time_zone 1";
                } else {
                    Calendar calendar = Calendar.getInstance();
                    calendar.add(Calendar.DAY_OF_YEAR, action);
                    intended = calendar.getTimeInMillis();
                    command = "settings put global auto_time 0 && cmd alarm set-time " + intended;
                }
                Process process = Shizuku.newProcess(new String[]{"sh", "-c", command}, null, null);
                StringBuilder output = new StringBuilder();
                try (BufferedReader stdout = new BufferedReader(new InputStreamReader(process.getInputStream()));
                     BufferedReader stderr = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
                    String line;
                    while ((line = stdout.readLine()) != null) output.append(line).append(' ');
                    while ((line = stderr.readLine()) != null) output.append(line).append(' ');
                }
                int exitCode = process.waitFor();
                boolean success = exitCode == 0;
                if (success && action == 0) {
                    success = Settings.Global.getInt(getContentResolver(), Settings.Global.AUTO_TIME, 0) == 1;
                } else if (success) {
                    success = Math.abs(System.currentTimeMillis() - intended) < 180000;
                }
                result = success ? (action == 0 ? "Otomatik tarih açıldı" : action < 0 ? "Bir gün geri alındı" : "Bir gün ileri alındı") :
                        (output.length() > 0 ? "Tarih değişmedi: " + output.toString().trim() : "Tarih değiştirilemedi (cihaz yetkisi)");
            } catch (Exception e) { result = "İşlem başarısız: " + e.getClass().getSimpleName(); }
            String finalResult = result;
            main.post(() -> { busy.set(false); message(finalResult); });
        }, "tarih-control-action").start();
    }
    private void message(String msg) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onDestroy() {
        running = false;
        if (windowManager != null && floatingPanel != null) {
            try { windowManager.removeView(floatingPanel); } catch (Exception ignored) {}
            floatingPanel = null;
        }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }

    private class IconView extends View {
        private final int action;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int tint;
        IconView(int action, int tint) { super(OverlayService.this); this.action = action; this.tint = tint; }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float scale = Math.min(getWidth(), getHeight()) / 100f;
            canvas.save();
            canvas.translate((getWidth() - 100 * scale) / 2f, (getHeight() - 100 * scale) / 2f);
            canvas.scale(scale, scale);
            paint.setColor(tint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(7);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            if (action == -1) {
                canvas.drawLine(74, 50, 27, 50, paint);
                canvas.drawLine(27, 50, 48, 29, paint);
                canvas.drawLine(27, 50, 48, 71, paint);
            } else if (action == 1) {
                canvas.drawLine(26, 50, 73, 50, paint);
                canvas.drawLine(73, 50, 52, 29, paint);
                canvas.drawLine(73, 50, 52, 71, paint);
            } else {
                canvas.drawArc(new RectF(20, 20, 80, 80), 42, 298, false, paint);
                canvas.drawLine(80, 25, 80, 45, paint);
                canvas.drawLine(80, 45, 59, 45, paint);
            }
            canvas.restore();
        }
    }
}
