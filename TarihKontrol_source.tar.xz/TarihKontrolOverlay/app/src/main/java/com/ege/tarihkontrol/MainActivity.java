package com.ege.tarihkontrol;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int SHIZUKU_REQUEST = 501;
    private TextView connection;
    private TextView overlayStatus;
    private Button permissionButton;
    private Button overlayButton;
    private final Shizuku.OnRequestPermissionResultListener listener = (request, result) -> {
        if (request == SHIZUKU_REQUEST) runOnUiThread(this::refresh);
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 16, 28));
        getWindow().setNavigationBarColor(Color.rgb(11, 16, 28));
        LinearLayout root = new LinearLayout(this);
        root.setGravity(Gravity.CENTER);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(26), dp(24), dp(26), dp(24));
        root.setBackgroundColor(Color.rgb(11, 16, 28));
        TextView emblem = label("◷", 58, 0xFF7DB4FF, true);
        emblem.setGravity(Gravity.CENTER);
        root.addView(emblem, new LinearLayout.LayoutParams(-1, dp(84)));
        TextView title = label("Tarih Kontrol", 26, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        connection = label("Shizuku kontrol ediliyor", 14, 0xFFA6B5CE, false);
        connection.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams conLp = new LinearLayout.LayoutParams(-1, dp(52));
        conLp.topMargin = dp(12);
        root.addView(connection, conLp);
        permissionButton = actionButton("Shizuku izni ver", 0xFF273957);
        LinearLayout.LayoutParams pLp = new LinearLayout.LayoutParams(-1, dp(52));
        pLp.topMargin = dp(16);
        root.addView(permissionButton, pLp);
        permissionButton.setOnClickListener(v -> requestShizuku());
        overlayButton = actionButton("Sabit paneli aç", 0xFF3975E8);
        LinearLayout.LayoutParams oLp = new LinearLayout.LayoutParams(-1, dp(58));
        oLp.topMargin = dp(12);
        root.addView(overlayButton, oLp);
        overlayButton.setOnClickListener(v -> toggleOverlay());
        overlayStatus = label("", 13, 0xFFA6B5CE, false);
        overlayStatus.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(-1, -2);
        sLp.topMargin = dp(18);
        root.addView(overlayStatus, sLp);
        setContentView(root);
        Shizuku.addRequestPermissionResultListener(listener);
        refresh();
    }

    private Button actionButton(String text, int bg) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(15);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(bg);
        drawable.setCornerRadius(dp(17));
        drawable.setStroke(dp(1), 0xFF4C607D);
        button.setBackground(drawable);
        return button;
    }
    private TextView label(String text, float size, int color, boolean bold) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(size);
        label.setTextColor(color);
        if (bold) label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return label;
    }
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    private boolean shizukuReady() {
        try { return Shizuku.getBinder() != null && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Exception e) { return false; }
    }
    private void refresh() {
        if (connection == null) return;
        boolean hasBinder = false;
        try { hasBinder = Shizuku.getBinder() != null; } catch (Exception ignored) {}
        if (!hasBinder) {
            connection.setText("Shizuku çalışmıyor");
            permissionButton.setText("Shizuku'yu aç");
            permissionButton.setVisibility(View.VISIBLE);
        } else if (!shizukuReady()) {
            connection.setText("Shizuku izni gerekli");
            permissionButton.setText("Shizuku izni ver");
            permissionButton.setVisibility(View.VISIBLE);
        } else {
            connection.setText("● Shizuku bağlı");
            connection.setTextColor(0xFF65DCA8);
            permissionButton.setVisibility(View.GONE);
        }
        overlayButton.setText(OverlayService.running ? "Sabit paneli kapat" : "Sabit paneli aç");
        overlayStatus.setText(OverlayService.running ? "Panel diğer uygulamaların üzerinde açık" : "Panel kapalı");
    }
    private void requestShizuku() {
        try {
            if (Shizuku.getBinder() == null) {
                Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (launch != null) startActivity(launch);
                else connection.setText("Önce Shizuku uygulamasını başlat");
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) Shizuku.requestPermission(SHIZUKU_REQUEST);
            refresh();
        } catch (Exception e) { connection.setText("Shizuku bağlantısı kurulamadı"); }
    }
    private void toggleOverlay() {
        if (OverlayService.running) {
            stopService(new Intent(this, OverlayService.class));
            overlayButton.postDelayed(this::refresh, 200);
            return;
        }
        if (!shizukuReady()) { requestShizuku(); return; }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return;
        }
        Intent intent = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
        else startService(intent);
        overlayButton.postDelayed(this::refresh, 300);
    }
    @Override protected void onResume() { super.onResume(); if (connection != null) refresh(); }
    @Override protected void onDestroy() { Shizuku.removeRequestPermissionResultListener(listener); super.onDestroy(); }
}
