package com.camonwalk.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.StepsRecord
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max

class MainActivity : ComponentActivity() {
    private val stepsPermission = HealthPermission.getWritePermission(StepsRecord::class)
    private lateinit var stepsInput: EditText
    private lateinit var minutesInput: EditText
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var permissionButton: Button
    private lateinit var statusText: TextView
    private lateinit var timeText: TextView
    private lateinit var progressText: TextView
    private lateinit var stepProgress: ProgressBar
    private val handler = Handler(Looper.getMainLooper())
    private var pendingSteps = 0
    private var pendingMinutes = 0

    private val healthPermissionLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        if (stepsPermission in granted) {
            toast("Adım yazma izni verildi")
            if (pendingSteps > 0) requestActivityPermissionOrStart()
        } else {
            pendingSteps = 0
            toast("Health Connect adım yazma izni gerekli")
        }
    }

    private val activityPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchWritingService()
        else {
            pendingSteps = 0
            toast("Arka planda çalışmak için fiziksel etkinlik izni gerekiyor")
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Bildirim izni olmasa da adım yazma çalışabilir. */ }

    private val ticker = object : Runnable {
        override fun run() {
            refreshProgress()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        stepsInput = findViewById(R.id.stepsInput)
        minutesInput = findViewById(R.id.minutesInput)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        permissionButton = findViewById(R.id.permissionButton)
        statusText = findViewById(R.id.statusText)
        timeText = findViewById(R.id.timeText)
        progressText = findViewById(R.id.progressText)
        stepProgress = findViewById(R.id.stepProgress)

        permissionButton.setOnClickListener { ensureHealthPermission(false) }
        startButton.setOnClickListener {
            val steps = stepsInput.text.toString().toIntOrNull()
            val minutes = minutesInput.text.toString().toIntOrNull()
            if (steps == null || steps !in 1..200000 || minutes == null || minutes !in 1..720) {
                toast("1–200.000 adım ve 1–720 dakika aralığında değer gir")
                return@setOnClickListener
            }
            if (getSharedPreferences(StepWriterService.PREFS, MODE_PRIVATE)
                    .getBoolean(StepWriterService.KEY_ACTIVE, false)) {
                toast("Önce devam eden kaydı durdur")
                return@setOnClickListener
            }
            pendingSteps = steps
            pendingMinutes = minutes
            ensureHealthPermission(true)
        }
        stopButton.setOnClickListener {
            startService(Intent(this, StepWriterService::class.java).apply {
                action = StepWriterService.ACTION_STOP
            })
            toast("Durdurma isteği gönderildi")
            refreshProgress()
        }
        refreshProgress()
        checkHealthStatus()
    }

    override fun onStart() {
        super.onStart()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onStop() {
        handler.removeCallbacks(ticker)
        super.onStop()
    }

    private fun checkHealthStatus() {
        when (HealthConnectClient.getSdkStatus(this)) {
            HealthConnectClient.SDK_UNAVAILABLE -> statusText.text = "Health Connect bu cihazda kullanılamıyor"
            HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> {
                statusText.text = "Health Connect kurulu değil veya güncellenmeli"
            }
        }
    }

    private fun ensureHealthPermission(startAfter: Boolean) {
        when (HealthConnectClient.getSdkStatus(this)) {
            HealthConnectClient.SDK_UNAVAILABLE -> {
                pendingSteps = 0
                toast("Bu cihaz Health Connect'i desteklemiyor")
                return
            }
            HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> {
                pendingSteps = 0
                toast("Önce Health Connect'i yükle veya güncelle")
                val url = Uri.parse("market://details?id=com.google.android.apps.healthdata")
                try { startActivity(Intent(Intent.ACTION_VIEW, url)) }
                catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.healthdata"))) }
                return
            }
        }
        lifecycleScope.launch {
            try {
                val client = HealthConnectClient.getOrCreate(this@MainActivity)
                val granted = client.permissionController.getGrantedPermissions()
                if (stepsPermission !in granted) {
                    if (!startAfter) pendingSteps = 0
                    healthPermissionLauncher.launch(setOf(stepsPermission))
                } else if (startAfter) {
                    requestActivityPermissionOrStart()
                } else {
                    toast("Health Connect adım yazma izni zaten var")
                }
            } catch (e: Exception) {
                pendingSteps = 0
                statusText.text = "İzin kontrolü başarısız: ${e.localizedMessage ?: "Bilinmeyen hata"}"
            }
        }
    }

    private fun requestActivityPermissionOrStart() {
        if (Build.VERSION.SDK_INT >= 29 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            activityPermissionLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
        } else {
            launchWritingService()
        }
    }

    private fun launchWritingService() {
        if (pendingSteps <= 0 || pendingMinutes <= 0) return
        val intent = Intent(this, StepWriterService::class.java).apply {
            action = StepWriterService.ACTION_START
            putExtra(StepWriterService.EXTRA_STEPS, pendingSteps)
            putExtra(StepWriterService.EXTRA_MINUTES, pendingMinutes)
        }
        try {
            ContextCompat.startForegroundService(this, intent)
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            toast("Adım kaydı başlatılıyor")
        } catch (e: Exception) {
            statusText.text = "Başlatılamadı: ${e.localizedMessage}"
        } finally {
            pendingSteps = 0
            pendingMinutes = 0
        }
    }

    private fun refreshProgress() {
        val p = getSharedPreferences(StepWriterService.PREFS, MODE_PRIVATE)
        val target = p.getInt(StepWriterService.KEY_TARGET, 0)
        val done = p.getInt(StepWriterService.KEY_WRITTEN, 0)
        val isRunning = p.getBoolean(StepWriterService.KEY_ACTIVE, false)
        val duration = p.getLong(StepWriterService.KEY_DURATION, 0L)
        val start = p.getLong(StepWriterService.KEY_START, 0L)
        val format = NumberFormat.getIntegerInstance(Locale("tr", "TR"))
        progressText.text = "${format.format(done)} / ${format.format(target)}"
        stepProgress.progress = if (target > 0) (done.toLong() * 100 / target).toInt() else 0
        val remainingSeconds = max(0L, (start + duration - System.currentTimeMillis() + 999) / 1000)
        timeText.text = if (isRunning) "Kalan süre: ${remainingSeconds / 60} dk ${remainingSeconds % 60} sn" else "Kalan süre: --"
        val error = p.getString(StepWriterService.KEY_ERROR, "").orEmpty()
        statusText.text = when {
            error.isNotBlank() -> "Hata: $error"
            isRunning -> "Çalışıyor • Health Connect'e aşamalı kaydediliyor"
            target > 0 && done >= target -> "Tamamlandı • $done adım kaydedildi"
            target > 0 -> "Durduruldu • $done adım kaydedildi"
            else -> "Hazır • Başlamak için izin ver"
        }
        startButton.isEnabled = !isRunning
        stopButton.isEnabled = isRunning
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
