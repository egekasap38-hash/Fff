package com.camonwalk.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.metadata.Metadata
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId
import kotlin.math.max
import kotlin.math.min

/** Gerçek sensör verisini değiştirmez; Health Connect'e elle girilmiş test kayıtları yazar. */
class StepWriterService : Service() {
    companion object {
        const val PREFS = "camonwalk_session"
        const val KEY_ACTIVE = "active"
        const val KEY_TARGET = "target"
        const val KEY_WRITTEN = "written"
        const val KEY_DURATION = "duration_ms"
        const val KEY_START = "start_ms"
        const val KEY_LAST_END = "last_end_ms"
        const val KEY_ERROR = "error"
        const val ACTION_START = "com.camonwalk.app.START"
        const val ACTION_STOP = "com.camonwalk.app.STOP"
        const val EXTRA_STEPS = "steps"
        const val EXTRA_MINUTES = "minutes"
        private const val CHANNEL = "camonwalk_steps"
        private const val NOTIFICATION_ID = 27
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Adım kaydı", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
            job?.cancel()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_START) {
            val total = intent.getIntExtra(EXTRA_STEPS, 0)
            val minutes = intent.getIntExtra(EXTRA_MINUTES, 0)
            if (total !in 1..200000 || minutes !in 1..720 || prefs.getBoolean(KEY_ACTIVE, false)) {
                if (job == null) stopSelf()
                return START_NOT_STICKY
            }
            val now = System.currentTimeMillis()
            prefs.edit().putBoolean(KEY_ACTIVE, true).putInt(KEY_TARGET, total)
                .putInt(KEY_WRITTEN, 0).putLong(KEY_START, now)
                .putLong(KEY_DURATION, minutes.toLong() * 60_000L)
                .putLong(KEY_LAST_END, now).putString(KEY_ERROR, "").commit()
        }
        if (!prefs.getBoolean(KEY_ACTIVE, false)) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val notification = createNotification(prefs.getInt(KEY_WRITTEN, 0), prefs.getInt(KEY_TARGET, 0))
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            prefs.edit().putBoolean(KEY_ACTIVE, false).putString(KEY_ERROR,
                "Arka plan hizmeti açılamadı: ${e.localizedMessage}").apply()
            stopSelf()
            return START_NOT_STICKY
        }
        if (job == null || job?.isCompleted == true) {
            job = scope.launch { writeStepsUntilFinished() }
        }
        return START_STICKY
    }

    private suspend fun writeStepsUntilFinished() {
        try {
            val client = HealthConnectClient.getOrCreate(this)
            val permission = HealthPermission.getWritePermission(StepsRecord::class)
            if (permission !in client.permissionController.getGrantedPermissions()) {
                throw IllegalStateException("Health Connect adım yazma izni verilmedi")
            }
            while (scope.isActive && prefs.getBoolean(KEY_ACTIVE, false)) {
                val now = System.currentTimeMillis()
                val start = prefs.getLong(KEY_START, now)
                val duration = prefs.getLong(KEY_DURATION, 1L).coerceAtLeast(1L)
                val total = prefs.getInt(KEY_TARGET, 0)
                val alreadyWritten = prefs.getInt(KEY_WRITTEN, 0)
                // Long hesaplama taşmayı ve zamanlayıcının birkaç saniye gecikmesini tolere eder.
                val elapsed = (now - start).coerceIn(0L, duration)
                val desired = min(total.toLong(), total.toLong() * elapsed / duration).toInt()
                val delta = desired - alreadyWritten
                if (delta > 0) {
                    val prevEnd = prefs.getLong(KEY_LAST_END, start)
                    val intervalStart = Instant.ofEpochMilli(min(prevEnd, now - 1L))
                    val intervalEnd = Instant.ofEpochMilli(max(now, prevEnd + 1L))
                    val zone = ZoneId.systemDefault()
                    val record = StepsRecord(
                        startTime = intervalStart,
                        endTime = intervalEnd,
                        startZoneOffset = zone.rules.getOffset(intervalStart),
                        endZoneOffset = zone.rules.getOffset(intervalEnd),
                        count = delta.toLong(),
                        metadata = Metadata.manualEntry()
                    )
                    // Yazma tamamlanmadan ilerleme sayacı artırılmaz.
                    client.insertRecords(listOf(record))
                    prefs.edit().putInt(KEY_WRITTEN, desired).putLong(KEY_LAST_END, now).commit()
                    (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                        .notify(NOTIFICATION_ID, createNotification(desired, total))
                }
                if (elapsed >= duration && desired == total) {
                    prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
                    break
                }
                delay(5000L)
            }
        } catch (_: CancellationException) {
            // Kullanıcı durdurdu; halihazırda kaydedilmiş adımlar korunur.
        } catch (e: Exception) {
            prefs.edit().putBoolean(KEY_ACTIVE, false).putString(KEY_ERROR,
                e.localizedMessage ?: "Adım kaydı başarısız").apply()
        } finally {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun createNotification(done: Int, total: Int): Notification {
        val openIntent = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stopIntent = PendingIntent.getService(this, 1,
            Intent(this, StepWriterService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_myplaces)
            .setContentTitle("CamonWalk • adım kaydı")
            .setContentText("$done / $total adım Health Connect'e kaydedildi")
            .setProgress(total.coerceAtLeast(1), done, false)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_pause, "Durdur", stopIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }
}
