package com.camonwalk.app

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class PermissionsRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Gizlilik ve izinler"
        setContentView(TextView(this).apply {
            setPadding(40, 60, 40, 40)
            textSize = 17f
            text = "CamonWalk, girdiğin adım sayısını belirlediğin süre boyunca Health Connect'e test amaçlı ve elle girilmiş veri olarak kaydeder. Yalnızca adım yazma izni ister. Kayıtlarını okumaz, internete göndermez ve üçüncü taraflara aktarmaz. Arka planda devam edebilmek için hareket etkinliği izni kullanılır; fiziksel sensör okuması yapılmaz. İzinleri Android ayarlarından istediğin zaman iptal edebilirsin."
        })
    }
}
