# CamonWalk — Android adım kaydı simülatörü

TECNO Camon 20 gibi root erişimi olmayan Android cihazları için hazırlanmış bir **kaynak kod projesi**.

## Ne yapıyor?

- Kullanıcının girdiği **adım sayısını** ve **dakikayı** alır.
- **Başlat** butonuyla belirtilen süre boyunca yaklaşık 5 saniyede bir yeni adım kayıtları üretir.
- Kayıtları Health Connect'e `StepsRecord`, `Metadata.manualEntry()` olarak yazar.
- **Durdur** butonu, ilerleme göstergesi, kalan süre ve arka planda çalışmak için bildirim içerir.
- Kullanıcı Health Connect yazma izni verir. Android 14+ üzerinde sağlık tipi foreground service gereksinimi için `ACTIVITY_RECOGNITION` izni de ister.
- Hiçbir ağ servisine veri göndermez, gerçek fiziksel adım sensörünü değiştirmez.

**Önemli sınır:** Bu uygulama TECNO Sağlık uygulamasının doğrudan Android'in donanım adım sensöründen okuduğu sayıları değiştiremez. Health Connect'e yazılan adımlar ancak o kaynağı okuyabilen uygulamalarda görünebilir. Her uygulamada görünmesi garanti değildir.

## APK oluşturma

Bu ZIP bir **APK değil**, Android kaynak kodudur. Dışa bağımlılıkları indiren ve Android SDK kurulu bir derleyicinin gerektiği bir projedir.

### GitHub Actions ile (kendi bilgisayarında Android Studio gerektirmez)

1. GitHub'da yeni bir depo oluştur.
2. Bu projenin **içindeki** tüm dosyaları, `.github/workflows/build-apk.yml` dahil, depoya yükle. ZIP'i tek dosya olarak yüklemek yeterli değildir; klasör içeriği açılmış olmalı.
3. Deponun **Actions** sekmesine gir ve **CamonWalk APK olustur** akışını çalıştır. `main` veya `master` dalına yaptığın ilk yükleme de derlemeyi tetikler.
4. Başarılı derlemenin altında **CamonWalk-APK** adlı artifact ZIP'ini indir.
5. ZIP'i aç: içindeki `app-debug.apk` dosyası Android'e kurulabilir APK'dır.

### Android Studio ile

- Android Studio'da bu klasörü proje olarak aç. Gradle 8.9, JDK 17, Android SDK 35 gereklidir.
- `gradle :app:assembleDebug` çalıştır. APK yolu: `app/build/outputs/apk/debug/app-debug.apk`.

## Telefon kurulumu

1. Health Connect'in güncel olması gerekir; Android 13'te Google Play'den kurulur, Android 14+ cihazlarda genellikle sisteme entegredir.
2. APK'yi kur, CamonWalk'u aç, **Adım yazma izni ver** butonuna bas.
3. Adım sayısını (1–200.000) ve süreyi (1–720 dakika) gir.
4. **Başlat** ile kayıt oluşturmaya başla. Bildirimde kalan kayıt ilerler; **Durdur** istediğinde bitirir.
5. TECNO Sağlık veya Google Fit ekranında güncelleme görünmesi, ilgili uygulamanın Health Connect verilerini okuyup kullanmasına bağlıdır.

## Teknik detaylar

- Paket adı: `com.camonwalk.app`
- Kotlin, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Health Connect client 1.1.0.
- Min SDK 28, target SDK 35, Java 17.
- Foreground service adım üretimi telefon ekranı kapalıyken devam ettirmeye çalışır; Android pil optimizasyonları veya izin değişiklikleri servisi durdurabilir.
- Adım kayıtları `Metadata.manualEntry()` ile açık şekilde elle girilmiş veri olarak işaretlenir. Gerçek hareket/sensör ölçümü gibi sunulmaz.
- Proje burada Android SDK ve Gradle erişimi olmadığı için bu ortamda derlenemedi; cihaz üzerinde çalışma testi yapılmadı.

## Resmî kaynaklar

- https://developer.android.com/health-and-fitness/health-connect/features/steps
- https://developer.android.com/health-and-fitness/health-connect/write-data
- https://developer.android.com/develop/background-work/services/fgs/service-types
