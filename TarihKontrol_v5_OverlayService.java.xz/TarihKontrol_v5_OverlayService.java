package com.ege.tarihkontrol;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import rikka.shizuku.Shizuku;

public class OverlayService extends Service {
    public static final String ACTION_RESET_POSITIONS = "com.ege.tarihkontrol.RESET_POSITIONS";
    static volatile boolean running = false;

    private static final String CHANNEL = "tarih_kontrol_overlay";
    private static final String POSITION_PREFS = "floating_button_positions_v5";
    private static final Pattern COMPONENT = Pattern.compile("([a-zA-Z_][a-zA-Z0-9_.]*)/([a-zA-Z_.$][a-zA-Z0-9_.$]*)");
    private static final String APP_PACKAGE = "com.ege.tarihkontrol";
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final int[] buttonColors = {0xFFFFB76D, 0xFF79B1FF, 0xFF6DDCB3};
    private final List<FloatingButton> buttons = new ArrayList<>();
    private WindowManager windowManager;
    private SharedPreferences prefs;

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(POSITION_PREFS, MODE_PRIVATE);
        createNotification();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createButtons();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_RESET_POSITIONS.equals(intent.getAction())) {
            resetPositions();
        }
        return START_STICKY;
    }

    private void createNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Tarih Kontrol Paneli", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Sürüklenebilir ekran üstü tarih butonları");
            manager.createNotificationChannel(channel);
        }
        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(this, 0, open, flags);
        Notification notification = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("Tarih Kontrol")
                .setContentText("Butonlara dokun veya ayrı ayrı sürükle")
                .setContentIntent(pending)
                .setOngoing(true)
                .build();
        startForeground(1207, notification);
    }

    private Point screenSize() {
        Point size = new Point();
        windowManager.getDefaultDisplay().getSize(size);
        return size;
    }

    private void createButtons() {
        Point screen = screenSize();
        int size = dp(56);
        int gap = dp(12);
        int left = Math.max(0, (screen.x - (3 * size + 2 * gap)) / 2);
        int top = Math.max(dp(32), screen.y - size - dp(72));
        for (int i = 0; i < 3; i++) {
            int action = i - 1;
            IconView icon = new IconView(action, buttonColors[i]);
            icon.setContentDescription(action < 0 ? "Bir gün geri" : action == 0 ? "Otomatik tarih" : "Bir gün ileri");
            GradientDrawable background = new GradientDrawable();
            background.setColor(action == 0 ? 0xEE233752 : 0xEE17263C);
            background.setCornerRadius(dp(18));
            background.setStroke(dp(1), 0xB45B7292);
            icon.setBackground(background);
            icon.setElevation(dp(6));
            int kind = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    size, size, kind,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.LEFT;
            params.x = clamp(prefs.getInt("x_" + action, left + i * (size + gap)), 0, Math.max(0, screen.x - size));
            params.y = clamp(prefs.getInt("y_" + action, top), dp(24), Math.max(dp(24), screen.y - size - dp(12)));
            FloatingButton button = new FloatingButton(icon, params, action);
            icon.setOnClickListener(v -> runAction(action));
            icon.setOnTouchListener(button);
            try {
                windowManager.addView(icon, params);
                buttons.add(button);
            } catch (Exception error) {
                message("Ekran üstü panel izni gerekiyor");
                stopSelf();
                return;
            }
        }
        running = true;
    }

    private final class FloatingButton implements View.OnTouchListener {
        private final View view;
        private final WindowManager.LayoutParams params;
        private final int action;
        private float downX, downY;
        private int originX, originY;
        private boolean moving;
        private final int slop = ViewConfiguration.get(OverlayService.this).getScaledTouchSlop();

        FloatingButton(View view, WindowManager.LayoutParams params, int action) {
            this.view = view;
            this.params = params;
            this.action = action;
        }

        @Override public boolean onTouch(View v, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getRawX();
                    downY = event.getRawY();
                    originX = params.x;
                    originY = params.y;
                    moving = false;
                    v.setPressed(true);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float deltaX = event.getRawX() - downX;
                    float deltaY = event.getRawY() - downY;
                    if (!moving && Math.hypot(deltaX, deltaY) > slop) moving = true;
                    if (moving) {
                        v.setPressed(false);
                        Point size = screenSize();
                        params.x = clamp(originX + Math.round(deltaX), 0, Math.max(0, size.x - params.width));
                        params.y = clamp(originY + Math.round(deltaY), dp(24), Math.max(dp(24), size.y - params.height - dp(12)));
                        try { windowManager.updateViewLayout(view, params); } catch (Exception ignored) {}
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    v.setPressed(false);
                    if (moving) {
                        prefs.edit().putInt("x_" + action, params.x).putInt("y_" + action, params.y).apply();
                    } else {
                        v.performClick();
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    v.setPressed(false);
                    if (moving) prefs.edit().putInt("x_" + action, params.x).putInt("y_" + action, params.y).apply();
                    return true;
                default:
                    return false;
            }
        }
    }

    private void resetPositions() {
        prefs.edit().clear().apply();
        Point screen = screenSize();
        int size = dp(56), gap = dp(12);
        int left = Math.max(0, (screen.x - (3 * size + 2 * gap)) / 2);
        int top = Math.max(dp(32), screen.y - size - dp(72));
        for (int i = 0; i < buttons.size(); i++) {
            FloatingButton button = buttons.get(i);
            button.params.x = left + i * (size + gap);
            button.params.y = top;
            try { windowManager.updateViewLayout(button.view, button.params); } catch (Exception ignored) {}
        }
        message("Butonlar varsayılan konumlarına döndü");
    }

    private int clamp(int value, int min, int max) { return Math.min(max, Math.max(min, value)); }

    private void runAction(int action) {
        if (!busy.compareAndSet(false, true)) return;
        if (!shizukuReady()) {
            message("Shizuku bağlantısını kontrol et");
            busy.set(false);
            return;
        }
        new Thread(() -> {
            String result;
            boolean returned = false;
            try {
                // Capture the currently running activity before moving to the home screen.
                String foreground = findForegroundComponent();
                if (foreground == null) {
                    result = "Açık oyun tespit edilemedi; işlem yapılmadı";
                } else {
                    // The home key does not kill the game's task/process.
                    ShellResult home = shell("input keyevent KEYCODE_HOME");
                    if (home.exit != 0) {
                        result = "Ana ekrana geçilemedi";
                    } else {
                        Thread.sleep(350);
                        String command;
                        long intended = 0;
                        if (action == 0) {
                            command = "settings put global auto_time 1 && settings put global auto_time_zone 1";
                        } else {
                            Calendar calendar = Calendar.getInstance();
                            calendar.add(Calendar.DAY_OF_YEAR, action);
                            intended = calendar.getTimeInMillis();
                            command = "settings put global auto_time 0 && cmd alarm set-time " + intended;
                        }
                        ShellResult change = shell(command);
                        boolean success = change.exit == 0;
                        if (success && action == 0) {
                            success = Settings.Global.getInt(getContentResolver(), Settings.Global.AUTO_TIME, 0) == 1;
                        } else if (success) {
                            success = Math.abs(System.currentTimeMillis() - intended) < 180000;
                        }
                        Thread.sleep(280);
                        // Reorder the existing activity back to front instead of force-stopping the game.
                        ShellResult resume = shell("am start --activity-reorder-to-front --activity-single-top -n " + foreground);
                        returned = resume.exit == 0 && !resume.output.toLowerCase().contains("error:");
                        if (!returned) {
                            // Try bringing the task's launcher entry to front as a fallback.
                            String pkg = foreground.substring(0, foreground.indexOf('/'));
                            ShellResult fallback = shell("monkey -p " + pkg + " -c android.intent.category.LAUNCHER 1");
                            returned = fallback.exit == 0 && !fallback.output.contains("No activities found");
                        }
                        if (!success) result = "Tarih değişmedi" + (change.output.isEmpty() ? " (cihaz yetkisi)" : ": " + shortText(change.output));
                        else result = action == 0 ? "Otomatik tarih açıldı" : action < 0 ? "1 gün geri alındı" : "1 gün ileri alındı";
                        if (!returned) result += " • Oyuna otomatik dönüş başarısız";
                    }
                }
            } catch (Exception e) {
                result = "İşlem başarısız: " + e.getClass().getSimpleName();
            }
            final String feedback = result;
            main.post(() -> { busy.set(false); message(feedback); });
        }, "tarih-overlay-action").start();
    }

    private boolean shizukuReady() {
        try { return Shizuku.getBinder() != null && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Exception ignored) { return false; }
    }

    private String findForegroundComponent() throws Exception {
        ShellResult top = shell("dumpsys activity activities | grep -m 2 -E 'topResumedActivity|mResumedActivity' ");
        String component = componentFrom(top.output);
        if (component == null) {
            ShellResult focus = shell("dumpsys window | grep -m 2 -E 'mCurrentFocus|mFocusedApp'");
            component = componentFrom(focus.output);
        }
        if (component != null && component.startsWith(APP_PACKAGE + "/")) return null;
        if (component != null && (component.startsWith("com.android.systemui/") || component.contains("launcher"))) return null;
        return component;
    }

    private String componentFrom(String text) {
        Matcher matcher = COMPONENT.matcher(text);
        while (matcher.find()) {
            String full = matcher.group(0);
            if (!full.startsWith(APP_PACKAGE + "/") && !full.startsWith("com.android.systemui/")) return full;
        }
        return null;
    }

    private static String shortText(String s) {
        s = s.replace('\n', ' ').trim();
        return s.length() > 90 ? s.substring(0, 90) : s;
    }

    private ShellResult shell(String command) throws Exception {
        Method method = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
        method.setAccessible(true);
        Process process = (Process) method.invoke(null, new Object[]{new String[]{"sh", "-c", command}, null, null});
        if (!process.waitFor(8, TimeUnit.SECONDS)) {
            process.destroy();
            return new ShellResult(-1, "Komut zaman aşımı");
        }
        StringBuilder output = new StringBuilder();
        try (BufferedReader stdout = new BufferedReader(new InputStreamReader(process.getInputStream()));
             BufferedReader stderr = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
            String line;
            while ((line = stdout.readLine()) != null && output.length() < 3500) output.append(line).append('\n');
            while ((line = stderr.readLine()) != null && output.length() < 3500) output.append(line).append('\n');
        }
        return new ShellResult(process.exitValue(), output.toString().trim());
    }

    private static final class ShellResult {
        final int exit;
        final String output;
        ShellResult(int exit, String output) { this.exit = exit; this.output = output; }
    }

    private void message(String value) { Toast.makeText(this, value, Toast.LENGTH_SHORT).show(); }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onDestroy() {
        running = false;
        if (windowManager != null) {
            for (FloatingButton button : buttons) {
                try { windowManager.removeView(button.view); } catch (Exception ignored) {}
            }
            buttons.clear();
        }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }

    private class IconView extends View {
        private final int action;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int tint;
        IconView(int action, int tint) { super(OverlayService.this); this.action = action; this.tint = tint; }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float scale = Math.min(getWidth(), getHeight()) / 100f;
            canvas.save();
            canvas.translate((getWidth() - 100 * scale) / 2f, (getHeight() - 100 * scale) / 2f);
            canvas.scale(scale, scale);
            paint.setColor(tint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(7);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            if (action < 0) {
                canvas.drawLine(74, 50, 27, 50, paint);
                canvas.drawLine(27, 50, 48, 29, paint);
                canvas.drawLine(27, 50, 48, 71, paint);
            } else if (action > 0) {
                canvas.drawLine(26, 50, 73, 50, paint);
                canvas.drawLine(73, 50, 52, 29, paint);
                canvas.drawLine(73, 50, 52, 71, paint);
            } else {
                canvas.drawArc(new RectF(20, 20, 80, 80), 42, 298, false, paint);
                canvas.drawLine(80, 25, 80, 45, paint);
                canvas.drawLine(80, 45, 59, 45, paint);
            }
            canvas.restore();
        }
    }
}
