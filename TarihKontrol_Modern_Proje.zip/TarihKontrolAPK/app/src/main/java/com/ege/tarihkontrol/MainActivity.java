package com.ege.tarihkontrol;

import android.app.Activity;
import android.os.Bundle;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE = 501;
    private static final int BG = Color.rgb(12, 16, 27);
    private static final int PANEL = Color.rgb(23, 30, 47);
    private static final int BORDER = Color.rgb(43, 53, 75);
    private static final int TEXT = Color.rgb(246, 248, 255);
    private static final int SUBTLE = Color.rgb(147, 158, 180);
    private static final int BLUE = Color.rgb(94, 158, 255);
    private static final int GREEN = Color.rgb(77, 216, 160);
    private static final int AMBER = Color.rgb(250, 186, 101);
    private TextView connectionText, dateText, timeText, messageText, permissionLabel;
    private LinearLayout permissionButton;
    private View[] actionButtons = new View[3];
    private boolean busy = false;
    private final Locale tr = new Locale("tr", "TR");

    private final BroadcastReceiver clockReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { updateClock(); }
    };
    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, result) -> {
        if (requestCode == REQUEST_CODE) {
            refreshConnection();
            if (result != PackageManager.PERMISSION_GRANTED) showMessage("İzin verilmedi", false);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window window = getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(BG);
        createInterface();
        Shizuku.addRequestPermissionResultListener(permissionListener);
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_TIME_TICK);
        filter.addAction(Intent.ACTION_TIME_CHANGED);
        filter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        registerReceiver(clockReceiver, filter);
        updateClock();
        refreshConnection();
    }

    private void createInterface() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        frame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setPadding(dp(22), dp(32), dp(22), dp(36));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -1));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));
        FrameLayout mark = new FrameLayout(this);
        mark.setBackground(round(Color.rgb(32, 48, 77), 15, Color.rgb(48, 72, 110)));
        LinearLayout.LayoutParams markLp = new LinearLayout.LayoutParams(dp(52), dp(52));
        header.addView(mark, markLp);
        Symbol logo = new Symbol(this, "calendar", BLUE);
        FrameLayout.LayoutParams logoLp = new FrameLayout.LayoutParams(dp(31), dp(31), Gravity.CENTER);
        mark.addView(logo, logoLp);
        TextView title = text("Tarih Kontrol", 21, TEXT, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, -2, 1);
        titleLp.leftMargin = dp(13);
        header.addView(title, titleLp);

        connectionText = text("Kontrol ediliyor", 11, SUBTLE, true);
        connectionText.setGravity(Gravity.CENTER);
        connectionText.setPadding(dp(11), dp(9), dp(11), dp(9));
        connectionText.setBackground(round(Color.rgb(30, 39, 56), 20, BORDER));
        header.addView(connectionText, new LinearLayout.LayoutParams(-2, -2));

        LinearLayout clockCard = new LinearLayout(this);
        clockCard.setGravity(Gravity.CENTER);
        clockCard.setOrientation(LinearLayout.VERTICAL);
        clockCard.setBackground(gradient(Color.rgb(28, 40, 65), Color.rgb(19, 27, 44), 26, Color.rgb(53, 70, 100)));
        clockCard.setPadding(dp(16), dp(41), dp(16), dp(41));
        clockCard.setElevation(dp(3));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.topMargin = dp(40);
        root.addView(clockCard, cardLp);

        TextView clockHeading = text("CİHAZ TARİHİ", 11, SUBTLE, true);
        clockHeading.setLetterSpacing(.16f);
        clockHeading.setGravity(Gravity.CENTER);
        clockCard.addView(clockHeading);
        dateText = text("—", 28, TEXT, true);
        dateText.setGravity(Gravity.CENTER);
        if (android.os.Build.VERSION.SDK_INT >= 26) dateText.setAutoSizeTextTypeUniformWithConfiguration(17, 29, 1, 1);
        LinearLayout.LayoutParams dateLp = new LinearLayout.LayoutParams(-1, dp(48));
        dateLp.topMargin = dp(11);
        clockCard.addView(dateText, dateLp);
        timeText = text("--:--", 37, BLUE, true);
        timeText.setGravity(Gravity.CENTER);
        timeText.setLetterSpacing(.05f);
        LinearLayout.LayoutParams timeLp = new LinearLayout.LayoutParams(-1, -2);
        timeLp.topMargin = dp(4);
        clockCard.addView(timeText, timeLp);

        TextView actionsHeading = text("TARİH KONTROLLERİ", 11, SUBTLE, true);
        actionsHeading.setLetterSpacing(.14f);
        LinearLayout.LayoutParams headingLp = new LinearLayout.LayoutParams(-1, -2);
        headingLp.topMargin = dp(35);
        headingLp.bottomMargin = dp(13);
        root.addView(actionsHeading, headingLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(actions, new LinearLayout.LayoutParams(-1, -2));
        addAction(actions, 0, "arrow-left", "−1 GÜN", AMBER, -1);
        addAction(actions, 1, "refresh", "OTOMATİK", BLUE, 0);
        addAction(actions, 2, "arrow-right", "+1 GÜN", GREEN, 1);

        permissionButton = new LinearLayout(this);
        permissionButton.setOrientation(LinearLayout.HORIZONTAL);
        permissionButton.setGravity(Gravity.CENTER);
        permissionButton.setPadding(dp(16), dp(13), dp(16), dp(13));
        permissionButton.setBackground(ripple(Color.rgb(31, 44, 66), 17, BORDER));
        LinearLayout.LayoutParams authLp = new LinearLayout.LayoutParams(-1, -2);
        authLp.topMargin = dp(23);
        root.addView(permissionButton, authLp);
        Symbol shield = new Symbol(this, "shield", BLUE);
        permissionButton.addView(shield, new LinearLayout.LayoutParams(dp(22), dp(22)));
        permissionLabel = text("İzin ver", 14, TEXT, true);
        LinearLayout.LayoutParams permLabelLp = new LinearLayout.LayoutParams(-2, -2);
        permLabelLp.leftMargin = dp(10);
        permissionButton.addView(permissionLabel, permLabelLp);
        permissionButton.setOnClickListener(v -> requestShizuku());

        messageText = text("", 13, SUBTLE, false);
        messageText.setGravity(Gravity.CENTER);
        messageText.setVisibility(View.GONE);
        LinearLayout.LayoutParams messageLp = new LinearLayout.LayoutParams(-1, -2);
        messageLp.topMargin = dp(18);
        root.addView(messageText, messageLp);
        setContentView(frame);
    }

    private void addAction(LinearLayout parent, int index, String icon, String label, int color, int action) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(4), dp(18), dp(4), dp(17));
        tile.setBackground(ripple(PANEL, 20, BORDER));
        LinearLayout.LayoutParams tileLp = new LinearLayout.LayoutParams(0, dp(124), 1);
        if (index > 0) tileLp.leftMargin = dp(8);
        parent.addView(tile, tileLp);
        Symbol symbol = new Symbol(this, icon, color);
        tile.addView(symbol, new LinearLayout.LayoutParams(dp(36), dp(36)));
        TextView caption = text(label, 11, TEXT, true);
        caption.setGravity(Gravity.CENTER);
        if (android.os.Build.VERSION.SDK_INT >= 26) caption.setAutoSizeTextTypeUniformWithConfiguration(9, 11, 1, 1);
        caption.setLetterSpacing(.04f);
        LinearLayout.LayoutParams captionLp = new LinearLayout.LayoutParams(-1, dp(27));
        captionLp.topMargin = dp(13);
        tile.addView(caption, captionLp);
        tile.setOnClickListener(v -> runAction(action));
        actionButtons[index] = tile;
    }

    private void updateClock() {
        if (dateText == null) return;
        Date now = new Date();
        dateText.setText(new SimpleDateFormat("d MMMM yyyy", tr).format(now));
        timeText.setText(new SimpleDateFormat("HH:mm", tr).format(now));
    }

    private void refreshConnection() {
        if (connectionText == null) return;
        try {
            if (Shizuku.getBinder() == null) {
                connectionText.setText("Kapalı");
                connectionText.setTextColor(AMBER);
                permissionLabel.setText("Shizuku'yu aç");
                permissionButton.setVisibility(View.VISIBLE);
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                connectionText.setText("Bağlı");
                connectionText.setTextColor(GREEN);
                permissionButton.setVisibility(View.GONE);
            } else {
                connectionText.setText("İzin gerekli");
                connectionText.setTextColor(AMBER);
                permissionLabel.setText("Shizuku izni ver");
                permissionButton.setVisibility(View.VISIBLE);
            }
        } catch (Exception e) {
            connectionText.setText("Bağlantı yok");
            connectionText.setTextColor(AMBER);
            permissionButton.setVisibility(View.VISIBLE);
        }
    }

    private void requestShizuku() {
        try {
            if (Shizuku.getBinder() == null) {
                Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (launch != null) startActivity(launch);
                else showMessage("Shizuku uygulamasını başlat", false);
                return;
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                refreshConnection();
                return;
            }
            Shizuku.requestPermission(REQUEST_CODE);
        } catch (Exception e) { showMessage("Shizuku bağlantısı kurulamadı", false); }
    }

    private void runAction(int action) {
        if (busy) return;
        try {
            if (Shizuku.getBinder() == null || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                refreshConnection();
                requestShizuku();
                return;
            }
        } catch (Exception e) { refreshConnection(); showMessage("Shizuku bağlantısı yok", false); return; }
        busy = true;
        for (View button : actionButtons) button.setEnabled(false);
        showMessage("Uygulanıyor…", true);
        new Thread(() -> {
            boolean ok = false;
            String result;
            try {
                String cmd;
                if (action == 0) {
                    cmd = "settings put global auto_time 1 && settings put global auto_time_zone 1";
                } else {
                    java.util.Calendar c = java.util.Calendar.getInstance();
                    c.add(java.util.Calendar.DAY_OF_YEAR, action);
                    long millis = c.getTimeInMillis();
                    cmd = "settings put global auto_time 0 && cmd alarm set-time " + millis;
                }
                Process p = Shizuku.newProcess(new String[]{"sh", "-c", cmd}, null, null);
                StringBuilder errors = new StringBuilder();
                try (BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
                     BufferedReader er = new BufferedReader(new InputStreamReader(p.getErrorStream()))) {
                    String line;
                    while ((line = in.readLine()) != null) { if (line.toLowerCase(Locale.ROOT).contains("error")) errors.append(line).append(' '); }
                    while ((line = er.readLine()) != null) errors.append(line).append(' ');
                }
                int code = p.waitFor();
                ok = code == 0 && errors.length() == 0;
                if (ok) result = action == 0 ? "Otomatik saat açıldı" : action < 0 ? "1 gün geri alındı" : "1 gün ileri alındı";
                else result = errors.length() > 0 ? "İşlem başarısız: " + errors.toString().trim() : "İşlem başarısız (" + code + ")";
            } catch (Exception e) { result = "İşlem yapılamadı: " + e.getMessage(); }
            final String notice = result;
            final boolean success = ok;
            runOnUiThread(() -> {
                busy = false;
                for (View button : actionButtons) button.setEnabled(true);
                showMessage(notice, success);
                updateClock();
                refreshConnection();
            });
        }).start();
    }

    private void showMessage(String message, boolean success) {
        if (messageText == null) return;
        messageText.setText(message);
        messageText.setTextColor(success ? GREEN : AMBER);
        messageText.setVisibility(View.VISIBLE);
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        view.setIncludeFontPadding(false);
        return view;
    }

    private GradientDrawable round(int color, int radius, int stroke) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radius));
        bg.setStroke(dp(1), stroke);
        return bg;
    }
    private GradientDrawable gradient(int first, int second, int radius, int stroke) {
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{first, second});
        bg.setCornerRadius(dp(radius));
        bg.setStroke(dp(1), stroke);
        return bg;
    }
    private RippleDrawable ripple(int background, int radius, int stroke) {
        return new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), round(background, radius, stroke), null);
    }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onResume() { super.onResume(); updateClock(); refreshConnection(); }
    @Override protected void onDestroy() {
        unregisterReceiver(clockReceiver);
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        super.onDestroy();
    }

    private static final class Symbol extends View {
        private final Paint pen = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final String name;
        private final int color;
        Symbol(Context context, String name, int color) { super(context); this.name = name; this.color = color; setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        private void line(Canvas c, float x1, float y1, float x2, float y2) { c.drawLine(x1, y1, x2, y2, pen); }
        @Override protected void onDraw(Canvas original) {
            super.onDraw(original);
            Canvas c = original;
            int save = c.save();
            c.translate((getWidth()-Math.min(getWidth(),getHeight())) / 2f, (getHeight()-Math.min(getWidth(),getHeight())) / 2f);
            float scale = Math.min(getWidth(),getHeight()) / 100f;
            c.scale(scale, scale);
            pen.setColor(color); pen.setStyle(Paint.Style.STROKE); pen.setStrokeWidth(7f); pen.setStrokeCap(Paint.Cap.ROUND); pen.setStrokeJoin(Paint.Join.ROUND);
            switch (name) {
                case "arrow-left":
                    line(c, 76, 50, 24, 50); line(c, 24, 50, 47, 27); line(c, 24, 50, 47, 73); break;
                case "arrow-right":
                    line(c, 24, 50, 76, 50); line(c, 76, 50, 53, 27); line(c, 76, 50, 53, 73); break;
                case "refresh": {
                    c.drawArc(new RectF(19, 19, 81, 81), 55, 300, false, pen);
                    line(c, 80, 26, 80, 46); line(c, 80, 46, 60, 45); break;
                }
                case "shield": {
                    Path path = new Path(); path.moveTo(50, 11); path.lineTo(79, 22); path.lineTo(76, 58);
                    path.cubicTo(75, 71, 64, 81, 50, 89); path.cubicTo(36, 81, 25, 71, 24, 58);
                    path.lineTo(21, 22); path.close(); c.drawPath(path, pen);
                    line(c, 38, 50, 47, 59); line(c, 47, 59, 64, 41); break;
                }
                case "calendar": {
                    c.drawRoundRect(new RectF(17, 23, 83, 83), 10, 10, pen);
                    line(c, 17, 41, 83, 41); line(c, 35, 14, 35, 31); line(c, 65, 14, 65, 31);
                    pen.setStyle(Paint.Style.FILL);
                    c.drawRoundRect(new RectF(33, 53, 43, 63), 2, 2, pen);
                    c.drawRoundRect(new RectF(54, 53, 64, 63), 2, 2, pen);
                    break;
                }
            }
            c.restoreToCount(save);
        }
    }
}
