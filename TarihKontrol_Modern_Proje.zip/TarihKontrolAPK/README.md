# Tarih Kontrol 3.0

Sade karanlık arayüz, ikonlu -1 gün / otomatik / +1 gün kontrolleri, canlı cihaz tarih/saat kartı, Shizuku bağlantı durum etiketi ve özel uygulama ikonu.

## Gereksinimler
- Android 6.0 veya sonrası
- Shizuku uygulaması ve çalışan Shizuku servisi
- Shizuku yetkilendirmesi

## Derleme
Android Studio ile projeyi açıp `:app:assembleDebug` görevini çalıştırın. Alternatif: Gradle 8.9 / Android SDK 35 ve Android Gradle Plugin 8.7.3 ile `gradle :app:assembleDebug`.

**Not:** Sistem tarihini değiştirme yetkisi Android sürümüne ve Shizuku servis yetkilerine bağlıdır; tüm cihazlarda garantili değildir.
